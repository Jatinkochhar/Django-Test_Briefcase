from django.apps import AppConfig


class LearnConfig(AppConfig):
    name = 'learn'

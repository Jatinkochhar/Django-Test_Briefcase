from django.contrib import admin
from .models import Learn

# Register your models here.
admin.site.register(Learn)